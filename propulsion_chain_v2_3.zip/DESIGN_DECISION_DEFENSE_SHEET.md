# Design Decision Defense Sheet

One entry per choice a judge might probe. Each follows the same shape:
**What → Why → Assumption → What we'd check next.** Read this the night
before, don't memorize it — the shape is what matters, not the wording.

---

### Why PSO, not Genetic Algorithm / Simulated Annealing / gradient methods?
**What:** Particle Swarm Optimization, 30 particles × 50 iterations.
**Why:** Our design space is continuous (engine kW, battery Ah, motor
count, generator kW, motor kW) rather than combinatorial, and PSO is
straightforward to implement and tune for exactly that kind of
continuous multi-variable problem on a hackathon timeline.
**Assumption:** We assumed PSO's tendency to converge on a good local
optimum (rather than guaranteeing the global one) is an acceptable
trade-off given the smooth, single-basin shape we expect this objective
to have — we haven't proven the landscape is single-basin.
**Next:** Benchmark against GA and a simple gradient/pattern-search
method on the same objective function, compare convergence speed and
final fitness across multiple random seeds.

---

### Why LiPo, not LiFePO4 or Li-ion 21700 cells?
**What:** LiPo, 48V nominal.
**Why:** Highest specific energy of common UAV chemistries, which
matters directly for endurance, and it's the default assumption in most
of the reference material (Gudmundsson) our efficiency curves are based
on.
**Assumption:** We assumed specific energy is the dominant factor for
this mission profile; we did not weigh cycle life, thermal runaway risk,
or cold-weather performance, all of which would favor LiFePO4 in a
different mission.
**Next:** Re-run the same optimizer with LiFePO4's lower specific
energy and higher max discharge safety margin, compare endurance vs.
safety trade-off directly.

---

### Why 48V battery / 400V DC bus specifically?
**What:** 48V battery pack, 400V DC bus.
**Why:** Representative voltage classes for medium-power (40-80kW)
electric propulsion, chosen to keep current levels (and therefore
conductor/connector sizing) in a realistic range without introducing a
new optimization variable before the core architecture was validated.
**Assumption:** Voltage level was fixed as a baseline modeling choice,
not derived from an optimization.
**Next:** Add DC bus voltage and battery pack voltage as PSO variables
(noted already in our own equations doc as future work) — the
architecture is parameterized specifically so this is a config change,
not a rewrite.

---

### Why a series-hybrid (engine→generator→...→propeller) architecture, not parallel-hybrid?
**What:** Engine never mechanically drives the propeller — it only
drives a generator; all propulsive power goes through the electric
path.
**Why:** Matches the HAL challenge's stated interest in hybrid-electric
architectures and lets a single Energy Management Controller govern
the entire power balance through one bus, which is simpler to reason
about and instrument than a mechanical differential/clutch parallel
system.
**Assumption:** We assumed the efficiency losses from the extra
conversion stages (generator, rectifier, inverter) are acceptable given
the operational flexibility gained (engine can run at a fixed efficient
RPM regardless of propeller speed).
**Next:** Model a parallel-hybrid variant and compare total chain
efficiency at cruise — likely parallel wins on efficiency, series wins
on control flexibility; that trade-off itself is worth stating even
without building it.

---

### Why these specific propeller/motor RPM numbers (2550 rpm prop, 17000 rpm motor, 4:1 gearbox)?
**What:** Motor spins at high RPM (typical of small aerospace PMSMs),
reduced 4:1 to a propeller RPM that keeps the advance ratio J near
where our thrust/power coefficient curves are actually valid.
**Why:** This was tuned deliberately, not guessed — we hand-calculated
the advance ratio at cruise speed and adjusted the gearbox ratio until
J landed inside the valid range of our propeller model, instead of
leaving it wherever the first draft happened to put it.
**Assumption:** Single fixed-pitch propeller design point; no
variable-pitch modeling.
**Next:** Import a real manufacturer propeller chart instead of a
hand-fit polynomial, if we get a specific propeller vendor's data.

---

### Why PSO's objective weights (0.7 expected + 0.3 worst-case, 0.5/0.3 penalty coefficients)?
**What:** Specific numeric weights blending time-weighted expected
endurance with a worst-case (aged-engine) guarantee.
**Why:** Chosen to make the worst-case term meaningfully influence the
result without letting it dominate and produce an overly conservative
design that sandbags day-one performance.
**Assumption:** These weights are a reasoned starting point, not the
output of a sensitivity study.
**Next:** Sweep the 0.7/0.3 split and see how much the optimized design
actually changes — if it's insensitive across a wide range, that's
worth saying too ("the result is robust to this choice").

---

### Why did you build 6 new component classes instead of refining fewer things more deeply?
**What:** Generator, Rectifier, DC Bus, Inverter, Propeller, Energy
Management Controller — one class per physical subsystem.
**Why:** Matches how the real propulsion chain is physically decomposed
(each is a real, separate hardware stage with its own efficiency
curve), so the model's structure mirrors the system it represents —
easier to validate piece by piece and easier for a judge to audit than
one monolithic power-balance equation.
**Assumption:** Each component's efficiency curve is a representative
textbook shape (cited in our equations doc), not a specific datasheet.
**Next:** Replace the representative curves with real datasheet curves
once specific parts are chosen for a build.

---

## The one meta-answer that covers anything not listed above

> "We prioritized building and validating one complete, honestly-documented
> propulsion chain over comparing many partial alternatives. Every
> assumption is written down in our equations doc, and we can tell you
> exactly what we'd test next if we had more time — we just haven't
> run those comparisons yet."

That sentence is true, it's not defensive, and it answers "did you think
about this?" without pretending you did work you didn't do.

## What NOT to do
- Don't say "ChatGPT/Claude suggested it" as a reason — the reasoning
  above is now yours to own regardless of where the first draft came
  from; you understand why each choice was made.
- Don't apologize for not comparing everything — one clean sentence
  ("that's future work, here's specifically what we'd test") and move on.
- Don't let a hard question turn into an audit of the whole project —
  answer the one question asked, using the shape above, and stop.
