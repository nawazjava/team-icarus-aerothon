%% SANITY_CHECK.m
%  Run this by itself (after RUN_ME.m works, or instead of it) to get a
%  step-by-step trace of the baseline design. If SoC/fuel end up
%  drastically different from what's expected (fuel ~91kg, SoC ~24.5%
%  for the 60kW/100Ah/2-motor/60kW-generator/25kW-motor baseline), paste
%  this ENTIRE console output back - it pinpoints exactly which phase
%  and which variable diverges, instead of guessing at file versions again.

clc; clear all; close all;

aircraft.wing_area = 12; aircraft.aspect_ratio = 8.5; aircraft.cd0 = 0.025;
aero      = AerodynamicModel(aircraft.wing_area, aircraft.aspect_ratio, aircraft.cd0);
propeller = Propeller(1.8);
motor     = ElectricMotor(35, 20000);
inverter  = Inverter(70, 800);
dcbus     = DCBus(400, 0.01, 800);
battery   = BatteryPack('LiPo', 48, 80, 0.95);
rectifier = Rectifier(800);
generator = Generator(90, 30000, 230);
engine    = TurboshaftEngine(90, 30000);
emc       = EnergyManagementController(0.20, 0.30, 0.80, 2.5);

fprintf('gearbox_ratio should print 4:\n');
simulator = MissionSimulator(aero, propeller, motor, inverter, dcbus, ...
    battery, rectifier, generator, engine, emc, 10);
fprintf('  gearbox_ratio = %.1f (expect 4.0)\n', simulator.gearbox_ratio);
fprintf('  motor.max_rpm = %.0f (expect 20000)\n', motor.max_rpm);
fprintf('  prop_rpm implied = %.0f (expect ~3000)\n', (0.6*motor.max_rpm)/simulator.gearbox_ratio);

mission = Mission_7hr();
simulator = simulator.setup_mission(mission);

design.engine_power_kw = 90;
design.battery_capacity_Ah = 80;
design.num_motors = 2;
design.generator_power_kw = 90;
design.motor_power_kw = 35;

results = simulator.run_simulation(design);

fprintf('\n=== FINAL RESULT ===\n');
fprintf('Endurance: %.2f h | Fuel left: %.1f kg | SoC end: %.1f%% | Max deficit: %.2f kW | Feasible: %d\n', ...
    results.endurance_hours, results.fuel_mass(end), results.soc(end), ...
    results.max_power_deficit_kw, results.mission_feasible);
fprintf('EXPECTED (v2.6, larger fuel tank + smaller battery): Fuel reserve should now clear 10kg minimum, feasible=1\n\n');

fprintf('=== STEP-BY-STEP TRACE (every ~15 min) ===\n');
fprintf('%8s %8s %8s %10s %10s %8s %8s\n', 't(min)','alt(m)','V(m/s)','P_eng(kW)','P_batt(kW)','SoC(%)','Fuel(kg)');
N = numel(results.t);
stride = max(1, round(900/ (results.t(2)-results.t(1)))); % ~15 min steps at dt=10s
for i = 1:stride:N
    fprintf('%8.1f %8.0f %8.0f %10.1f %10.1f %8.1f %8.1f\n', ...
        results.t(i)/60, results.alt(i), results.speed(i), ...
        results.P_eng_shaft_kw(i), results.P_battery_dc_kw(i), ...
        results.soc(i), results.fuel_mass(i));
end
fprintf('%8.1f %8.0f %8.0f %10.1f %10.1f %8.1f %8.1f   <- FINAL STEP\n', ...
    results.t(N)/60, results.alt(N), results.speed(N), ...
    results.P_eng_shaft_kw(N), results.P_battery_dc_kw(N), ...
    results.soc(N), results.fuel_mass(N));
