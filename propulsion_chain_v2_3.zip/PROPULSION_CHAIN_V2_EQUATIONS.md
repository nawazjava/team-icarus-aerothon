# Propulsion Chain v2 — Equations, Assumptions, Data Sources

Architecture (series-hybrid / turbo-electric):

```
Aerodynamics → Required Thrust
    → Propeller → Required Shaft Power (per motor)
    → Gearbox (fixed ratio, fixed efficiency)
    → Motor (torque-speed envelope + efficiency map)
    → Inverter
    → DC Bus ←→ Battery
    ← Rectifier ← Generator ← Engine
```

An Energy Management Controller decides the Battery/Generator split at
every timestep based on mission phase and SoC.

## Why "required" flows backward, then a forward check
Each timestep, required power is solved backward from the aircraft to
the engine (aero → propeller → motor → inverter → EMC split → rectifier
→ generator → engine), then a **forward pass** recomputes what the
generator/rectifier/DC bus actually deliver using the engine's *capped*
shaft power. Any shortfall shows up as `deficit_kw` (logged every step,
`max_power_deficit_kw` in the results, penalized in the objective
function) rather than being silently absorbed. This is a standard
conceptual/preliminary-design simplification — components are evaluated
at their local operating point rather than solved as one simultaneous
system of equations — and it's flagged here rather than hidden.

## Generator (`Generator.m`)
- `P_ac = P_shaft * eta_gen(load_frac, speed_frac)`, peak ~96% near
  rated load/speed, falling at part load (iron/windage losses become a
  larger share of a smaller output).
- `I_ac = P_ac / (sqrt(3) * V_ac * pf)`, pf ≈ 0.95.
- Loss split (informational): copper loss grows with load², iron loss
  roughly constant with speed, mechanical loss small and constant.
- Source: representative aerospace PMSG efficiency-curve shape
  (Gudmundsson, *General Aviation Aircraft Design*, Ch.15 electric
  propulsion supplement). Replace with a specific datasheet once a
  generator is selected.

## Rectifier (`Rectifier.m`)
- `V_dc = 1.35*V_ac_line − 2*V_drop` (standard 3-phase bridge ratio).
- `eta_rect = eta0 − k_sw*load_frac` (switching loss grows with load).
- Source: standard 3-phase bridge topology (Mohan, Undeland & Robbins,
  *Power Electronics*, 3rd ed.).

## DC Bus (`DCBus.m`)
- Power balance: `P_in + P_batt_discharge = P_out + P_batt_charge + P_bus_loss`.
- `P_bus_loss = I_bus² * R_bus` (lumped busbar/connector resistance).
- Voltage treated as approximately regulated (set by the battery,
  clamped to bus limits) — standard lumped-bus simplification at this
  design level.

## Inverter (`Inverter.m`)
- `P_ac_motor = P_dc_in * eta_inv(load_frac)`, peak ~97%, penalized at
  light load (fixed switching losses dominate a small output) and
  slightly above rated.
- Source: typical aerospace SiC/IGBT inverter datasheet shape.

## Propeller (`Propeller.m`)
- `J = V/(n*D)` (advance ratio, n in rev/s), `CT(J)`, `CP(J)` quadratic
  fits, `T = CT*ρ*n²*D⁴`, `P = CP*ρ*n³*D⁵`, `eta_prop = J*CT/CP`.
- Default coefficients approximate a fixed-pitch cruise prop peaking
  ~85% efficiency near J≈0.65. Static thrust (V<1 m/s) uses simple
  momentum theory instead (`P ≈ T^1.5/√(2ρA)`) since the CT/CP fit is
  only valid in the cruise J-range.
- Source: Gudmundsson Ch.15, Raymer Ch.13 propeller charts.

## Battery (`BatteryPack.m`, upgraded)
- `OCV(SoC)`: piecewise-linear, steep near empty/full, flat plateau in
  the middle (typical Li-ion/LiPo rest-voltage shape).
- `V_terminal = OCV ∓ I*R_int` (sag on discharge, rise on charge).
- Retains the original Peukert correction and adds separate
  charge/discharge coulombic efficiencies (97%/98% LiPo).
- `R_int` scaled ~0.5 mΩ per Ah at a 100 Ah reference (pack-level,
  includes busbars/BMS).
- Source: Plett, *Battery Management Systems*, Vol. 1.

## Motor (`ElectricMotor.m`, upgraded)
- Torque-speed envelope: constant max torque below base speed
  (current-limited), constant max power above base speed
  (field-weakening): `T_max(rpm) = P_rated/ω` above base speed.
- Base speed assumed at 50% of max speed (typical aerospace PMSM).
- Power-based efficiency map retained (already captures the right
  qualitative peak-near-rated shape; a torque-based map would need
  motor-specific test data we don't have).
- Source: Gudmundsson Ch.15 electric-propulsion supplement.

## Aerodynamics (`AerodynamicModel.m`, upgraded)
- Now exposes `required_thrust()` (= drag at steady level flight)
  separately from `power_required()` (aerodynamic power at the
  airframe). Propeller efficiency is applied explicitly by
  `Propeller.m` rather than implicitly assumed to be 1.
- Steady, level-flight assumption: climb phases use a constant climb
  speed rather than an explicit flight-path angle, so no `W*sin(γ)`
  climb term is added — documented simplification, not hidden.

## Engine (`TurboshaftEngine.m`, unchanged from the bug-fixed version)
- Output is mechanical **shaft power** feeding the Generator (matches
  the series-hybrid architecture) — this was already correct in the
  existing model, just re-labeled conceptually.

## Energy Management Controller (`EnergyManagementController.m`)
- Takeoff/Climb: battery assists above generator's rated continuous
  power, capped at the battery's max discharge C-rate.
- Cruise: generator supplies demand; spare capacity trickle-charges the
  battery toward an 80% SoC target.
- Loiter: battery preferentially supplies power down to a 30% SoC
  floor.
- Descent/Landing: battery covers the small remaining demand.
- Safety floor: below 20% SoC, generator is forced to cover ~100% of
  demand regardless of phase.

## v2.2 fix log (feasibility-zero debug, verified by independent Python re-implementation)
The full chain was ported to Python and traced timestep-by-timestep to
find why every design remained infeasible even after v2.1. Two EMC bugs:
- **Battery power limit used the wrong voltage:** max battery power was
  computed as `C-rate x Ah x V_bus(400V)` instead of the battery's own
  48 V — overstating the battery's capability ~8x. The EMC was asking a
  ~5 kWh pack to carry a 44 kW loiter load for an hour, draining SoC to
  the 20% clamp and failing the end-of-mission SoC check every run.
- **Generator compared at rated kW, not deliverable kW:** the EMC
  assigned the generator any load below its *rated* power, ignoring
  generator+rectifier losses and the engine's cap. At cruise the engine
  needed ~61.5 kW shaft to deliver the 56.8 kW bus demand — 1.5 kW over
  a 60 kW engine, a chronic deficit no amount of battery/generator
  sizing could close because the comparison itself was wrong.
  `MissionSimulator` now computes `gen_dc_deliverable_kw` (engine cap x
  generator efficiency x rectifier efficiency) once per run and the EMC
  compares against that.
- Two strategy guards added: loiter battery only trims the load above
  60% of generator-deliverable (generator carries base load), and
  descent battery assist stops at a 25% SoC guard band so the final
  phase can't drive SoC into the 20% hard limit.
- **Verified:** with these fixes the 60 kW baseline completes the
  mission with 0 kW deficit, 24.5% end SoC, and 91 kg fuel remaining
  (feasible). The lifecycle sweep behaves as designed: engines below
  ~72 kW fail the 0.85-health case, so the robust optimizer has a real
  trade to make within its 40-80 kW bounds.

## v2.1 fix log (post first full-chain test run)
- **Propeller RPM mismatch (root cause of persistent power deficit):**
  the propeller was spinning at an RPM that put its advance ratio
  (`J ≈ 2.0` at cruise) far outside the range its CT/CP polynomial was
  fit for. The code clamped `J` to 1.2 and floored `eta_prop` at 0.35 to
  avoid a divide-by-zero, and that floor was silently the *operating*
  value on every phase - inflating required shaft power roughly 2x
  regardless of how large the engine/generator/battery were sized.
  Fixed by retuning `gearbox_ratio` (3.0→4.0) and motor `max_rpm`
  (5000→17000) so `J ≈ 0.4-0.8` across the mission's actual airspeeds,
  and rebalancing the CT/CP coefficients so efficiency doesn't collapse
  before that range. See comments in `Propeller.m` and the
  `MissionSimulator` constructor for the derivation.
- **Graduated feasibility penalty:** the objective function's
  feasibility term was a hard `1e6 if infeasible, 0 if feasible` step,
  which gave PSO no gradient to prefer a design that's short by 0.5 kW
  over one short by 25 kW - every infeasible candidate scored
  identically. Replaced with a smooth penalty scaled to the actual
  power deficit, end-of-mission SoC shortfall, and fuel shortfall.
- **Diagnostic breakdown:** `run_optimization.m` now prints which
  specific failure mode (generator+battery undersized / battery
  depleted / fuel exhausted) triggered infeasibility, instead of only a
  pass/fail flag.

## v2.4 fix log (cruise speed correction against official spec)
- **Cruise speed was wrong:** coded as 60 m/s (216 km/h); the actual
  baseline spec is ~250 km/h (69.4 m/s). This isn't cosmetic - required
  aerodynamic power at true cruise speed is ~29% higher (49.3 kW vs
  38.2 kW), and it also moves the propeller's advance ratio further
  from its design point, costing additional efficiency on top of that.
- Retuned propeller/motor RPM coupling for the corrected speed: motor
  `max_rpm` 17000→20000 (keeping `gearbox_ratio`=4.0), landing the
  propeller near J≈0.75 at the real cruise speed instead of the
  previous (also wrong-speed) tuning.
- Raised PSO bounds to cover the real power budget: engine/generator
  40-80kW → 60-130kW, battery 50-200Ah → 80-200Ah, motor 10-40kW →
  20-60kW per motor.
- Rebaselined the "baseline" design to 90kW engine / 120Ah battery /
  90kW generator / 35kW motors - deliberately just short of robust
  (fails only at 85% health, by 2.7 kW) so the optimizer has a
  meaningful, honest improvement to demonstrate. A confirmed fully
  feasible design exists within the new bounds: 100kW engine / 140Ah
  battery / 100kW generator / 38kW motors, feasible at all 4 health
  states (verified independently in Python before touching the MATLAB
  files - see the conversation history for the trace).

## v2.5 fix log (the real root cause of every "fuel=0, SoC=0" report)
- **Off-by-one in the mission loop's termination.** `step` was
  incremented at the top of each `while` iteration, but when the final
  mission phase finished, the code `break`-ed out immediately -
  *before* that iteration's physics and logging code ever ran. Every
  result array was then trimmed to `(1:step)`, which included that
  never-computed slot, still sitting at its preallocated zero. Every
  previous report of "Feasible: 0, fuel=0kg, SoC=0%" on an otherwise-
  healthy design was this phantom zero being read as the final value,
  not real depletion. This was present since the very first full-chain
  MissionSimulator rewrite and survived every physics fix so far,
  because it isn't a physics bug - it's an indexing bug that corrupts
  the very last entry of every logged quantity, independent of whether
  the underlying simulation is otherwise correct. Fixed by decrementing
  `step` before the final break, so trimming correctly excludes the
  unfilled slot.
- Fixed a units slip in `sanity_check.m`'s trace stride (was printing
  every 1.5 min instead of the intended 15 min - cosmetic only).

## v2.6 fix log (fuel margin, direct MATLAB fix - no side-channel verification)
- **Baseline was burning 144.6 kg against a 150 kg tank** - only 5.4 kg
  reserve, short of the 10 kg minimum. Not a power deficit (deficit was
  already 0 kW), purely a fuel-capacity margin issue.
- Fixed by reallocating within the existing MTOW budget, not by
  changing MTOW/payload/cruise speed/architecture: fuel tank
  150kg→170kg, baseline battery 120Ah→80Ah (38.4kg→25.6kg). The
  baseline's own trace showed the battery was barely drawn on (~0 kW
  for nearly the entire mission), so shrinking it doesn't cost
  anything that was actually being used.
- Weight check: 800 (empty) + 170 (fuel) + 25.6 (battery) = 995.6 kg,
  under the 1000 kg MTOW limit with a small margin to spare.

## What's simplified / left for future work
- Gearbox is a fixed ratio (3:1) + fixed efficiency (97%), not a full
  class — reasonable given the "(optional)" label on this node in the
  original architecture request.
- No battery thermal derating beyond the ESR itself; no explicit motor
  thermal model.
- Backward/forward split (see top) rather than one simultaneous
  electrical solve per timestep.
- Optimizer varies 5 variables (engine, battery, motor count,
  generator, motor size); DC bus voltage and propeller diameter are
  fixed design parameters rather than optimized, to keep the PSO search
  space tractable in the time available. Worth expanding if time
  allows.
