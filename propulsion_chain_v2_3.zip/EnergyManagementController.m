%% ============================================================================
%  ENERGY MANAGEMENT CONTROLLER CLASS  (NEW)
%  Decides battery vs engine-generator power split at every timestep
%  ============================================================================
%
%  Replaces the previous fixed "if takeoff: 60/40" rule with a strategy
%  keyed on mission phase, battery SoC, and instantaneous power demand.
%
%  Inputs:  mission phase, battery SoC, DC-bus power demand, generator
%           rated power, battery capacity, bus voltage
%  Outputs: P_battery_dc_kw            (+ = discharging into bus, - = charging)
%           P_generator_dc_required_kw (power the generator path must supply)
%
%  Strategy (documented assumptions):
%    Takeoff/Climb : battery assists (discharges) whenever demand exceeds
%                    the generator's rated continuous power, up to the
%                    battery's max discharge C-rate.
%    Cruise        : generator preferentially supplies full demand; any
%                    spare generator capacity trickle-charges the battery
%                    toward a cruise SoC target (default 80%).
%    Loiter        : battery preferentially supplies power (fuel economy)
%                    down to a minimum reserve SoC (default 30%).
%    Descent/Land  : minimal propulsion; battery covers the small demand.
%    Safety floor  : if SoC <= absolute floor (default 20%), generator is
%                    forced to cover ~100% of demand regardless of phase.

classdef EnergyManagementController
    properties
        soc_min_reserve
        soc_loiter_floor
        soc_cruise_target
        battery_max_c_rate
    end

    methods
        function obj = EnergyManagementController(soc_min_reserve, soc_loiter_floor, soc_cruise_target, battery_max_c_rate)
            if nargin < 1, soc_min_reserve = 0.20; end
            if nargin < 2, soc_loiter_floor = 0.30; end
            if nargin < 3, soc_cruise_target = 0.80; end
            if nargin < 4, battery_max_c_rate = 2.5; end
            obj.soc_min_reserve    = soc_min_reserve;
            obj.soc_loiter_floor   = soc_loiter_floor;
            obj.soc_cruise_target  = soc_cruise_target;
            obj.battery_max_c_rate = battery_max_c_rate;
        end

        function [P_battery_dc_kw, P_generator_dc_required_kw] = decide(obj, ...
                phase_name, soc, P_bus_demand_kw, gen_dc_deliverable_kw, battery_capacity_Ah, battery_V)

            % FIXED (v2.2): two unit/reference bugs found by tracing a full
            % mission timestep-by-timestep:
            %  (1) max battery power was computed with the DC BUS voltage
            %      (400 V) instead of the battery's own voltage (48 V),
            %      overstating the battery's capability ~8x. A 4.8 kWh
            %      pack was being asked to supply 44 kW for an hour.
            %  (2) the generator comparison used the generator's RATED kW,
            %      ignoring generator+rectifier losses and the engine's
            %      power cap - so the EMC assigned the generator loads it
            %      physically could not deliver, creating a chronic
            %      deficit at cruise. Callers must now pass
            %      gen_dc_deliverable_kw = what the generator path can
            %      actually put on the bus (see MissionSimulator).
            max_batt_power_kw = (obj.battery_max_c_rate * battery_capacity_Ah * battery_V) / 1000;
            g = gen_dc_deliverable_kw;

            if soc <= obj.soc_min_reserve
                % Safety override: generator covers everything (small
                % trickle charge only if it has genuine spare capacity)
                P_battery_dc_kw = -min(0.05*g, max(0, g - P_bus_demand_kw));
                P_generator_dc_required_kw = P_bus_demand_kw - P_battery_dc_kw;
                return;
            end

            switch phase_name
                case {'takeoff','climb'}
                    if P_bus_demand_kw > g
                        P_battery_dc_kw = min(max_batt_power_kw, P_bus_demand_kw - g);
                    else
                        P_battery_dc_kw = 0;
                    end

                case 'cruise'
                    if P_bus_demand_kw <= g && soc < obj.soc_cruise_target
                        surplus_kw = min(g - P_bus_demand_kw, 0.15*g);
                        P_battery_dc_kw = -surplus_kw;   % negative = charging
                    elseif P_bus_demand_kw > g
                        P_battery_dc_kw = min(max_batt_power_kw, P_bus_demand_kw - g);
                    else
                        P_battery_dc_kw = 0;
                    end

                case 'loiter'
                    % FIXED (v2.2): previously the battery tried to carry
                    % the ENTIRE loiter load (~44 kW from a ~5 kWh pack),
                    % draining to the floor in minutes. Now the battery
                    % only trims the peak above 60% of what the generator
                    % can deliver - generator carries the base load.
                    if soc > obj.soc_loiter_floor
                        P_battery_dc_kw = min(max_batt_power_kw, max(0, P_bus_demand_kw - 0.6*g));
                    else
                        P_battery_dc_kw = 0;
                    end

                otherwise  % descent / landing
                    % FIXED (v2.2): battery assists only above a 25% guard
                    % band, so it never gets driven into the 20% hard
                    % feasibility limit during the final phase.
                    if soc > obj.soc_min_reserve + 0.05
                        P_battery_dc_kw = min(max_batt_power_kw, P_bus_demand_kw);
                    else
                        P_battery_dc_kw = 0;
                    end
            end

            P_generator_dc_required_kw = max(0, P_bus_demand_kw - P_battery_dc_kw);
        end
    end
end
